const menu = [
    {
        id: 1,
        img: '../../public/image/americano-foam.jpg',
        name: 'americano-foam',
        desc: 'americano-foam',
        price: '30 Baht.',
    },
    {
        id: 2,
        img: '../../public/image/dark-rich-cocoa.jpg',
        name: 'dark-rich-cocoa',
        desc: 'dark-rich-cocoa',
        price: '30 Baht.',
    },
    {
        id: 3,
        img: '../../public/image/fruit-smoothie.jpg',
        name: 'fruit-smoothie',
        desc: '',
        price: '30 Baht.',
    },
    {
        id: 4,
        img: '',
        name: 'Thai milk tea',
        desc: '',
        price: '30 Baht.',
    },
    {
        id: 5,
        img: '',
        name: 'Thai milk tea',
        desc: '',
        price: '30 Baht.',
    },
    {
        id: 6,
        img: '',
        name: 'Thai milk tea',
        desc: '',
        price: '30 Baht.',
    },
    {
        id: 7,
        img: '',
        name: 'Thai milk tea',
        desc: '',
        price: '30 Baht.',
    },
    {
        id: 8,
        img: '',
        name: 'Thai milk tea',
        desc: '',
        price: '30 Baht.',
    },
    {
        id: 9,
        img: '',
        name: 'Thai milk tea',
        desc: '',
        price: '30 Baht.',
    },
    {
        id: 10,
        img: '',
        name: 'Thai milk tea',
        desc: '',
        price: '30 Baht.',
    },
]

export default menu;